import { Component, OnInit, OnDestroy } from '@angular/core';

import { Subscription, Observable, EMPTY } from 'rxjs';

import { Product } from '../product';
import { ProductService } from '../product.service';
import { catchError } from 'rxjs/operators';

@Component({
  selector: 'pm-product-list',
  templateUrl: './product-list-alt.component.html'
})
export class ProductListAltComponent {
  pageTitle = 'Products';
  errorMessage = '';


  products$: Observable<Product[]> = this.productService.productWithCategories$
  .pipe(

    catchError(err => {this.errorMessage = this.errorMessage; return EMPTY})
  ) ;
  selectedProduct$ = this.productService.selectedProduct$.
  pipe(
    catchError(err => {this.errorMessage = this.errorMessage; return EMPTY})

  )
  constructor(private productService: ProductService) { }





  onSelected(productId: number): void {
    this.productService.selectProductChanged(productId);
  }
}

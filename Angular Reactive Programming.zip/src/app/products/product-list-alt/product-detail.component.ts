import { Component } from '@angular/core';

import { ProductService } from '../product.service';
import { EMPTY } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Component({
  selector: 'pm-product-detail',
  templateUrl: './product-detail.component.html'
})
export class ProductDetailComponent {
  pageTitle = 'Product Detail';
  errorMessage = '';
  product;

  product$ = this.productService.selectedProduct$.
  pipe(
    catchError(err => {this.errorMessage = this.errorMessage; return EMPTY})

  )

  productSupplieres$ = this.productService.productSupplieres$.pipe(
    catchError(err => {this.errorMessage = this.errorMessage; return EMPTY})

  )
  constructor(private productService: ProductService) { }

}

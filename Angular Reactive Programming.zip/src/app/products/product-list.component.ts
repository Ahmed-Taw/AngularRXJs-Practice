import { Component, OnInit, OnDestroy } from '@angular/core';

import { Subscription, Observable, EMPTY, Subject, combineLatest } from 'rxjs';

import { Product } from './product';
import { ProductService } from './product.service';
import { catchError, map, startWith } from 'rxjs/operators';
import { ProductCategoryService } from '../product-categories/product-category.service';
import { ProductCategory } from '../product-categories/product-category';

@Component({
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  pageTitle = 'Product List';
  errorMessage = '';
  categories;

  private categorySelectedSubject = new Subject<number>();
  categorySelectedAction$ = this.categorySelectedSubject.asObservable();
  
  categories$: Observable<ProductCategory[]> = this.categoryService.productCategories$
  .pipe(
   catchError(err => {this.errorMessage = this.errorMessage; return EMPTY})
 
  );
 
  products$: Observable<Product[]> = combineLatest([
    this.productService.productWithCategories$,
    this.categorySelectedAction$.pipe(
      startWith(0)
    )
  ])
  .pipe(
     map(([products, categoryid ])=>{
return products.filter(product => categoryid ? product.categoryId === categoryid : true

      )
     })
     ,
    catchError(err => {this.errorMessage = this.errorMessage; return EMPTY})
  ) 


  
  constructor(private productService: ProductService,  private categoryService: ProductCategoryService) { }


  ngOnInit(): void {
    // this.products$ = this.productService.getProducts()
    // .pipe(
    //   catchError(error => {
    //     this.errorMessage = error;
    //     return EMPTY;
    //   })
    // );
  }

  
  onAdd(): void {
    console.log('Not yet implemented');
  }

  onSelected(categoryId: string): void {
    this.categorySelectedSubject.next(+categoryId);
  }
}
